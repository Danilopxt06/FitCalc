const nome   = localStorage.getItem('fitcalc_nome')   || 'Você';
const peso   = parseFloat(localStorage.getItem('fitcalc_peso'));
const altura = parseFloat(localStorage.getItem('fitcalc_altura'));

if (!peso || !altura) {
    window.location.href = './calculadora.html';
}

const alturaM = altura / 100;
const imc     = peso / (alturaM * alturaM);

let classe, cor, descricao;
if (imc < 18.5) {
    classe   = 'Abaixo do peso';
    cor      = '#3B82F6';
    descricao = 'Seu IMC indica que você está abaixo do peso ideal. Consulte um nutricionista para um plano alimentar adequado.';
} else if (imc < 25) {
    classe   = 'Peso normal';
    cor      = '#1D9E75';
    descricao = 'Parabéns! Seu peso está dentro da faixa saudável. Continue mantendo bons hábitos!';
} else if (imc < 30) {
    classe   = 'Sobrepeso';
    cor      = '#EF9F27';
    descricao = 'Seu IMC indica sobrepeso. Alimentação equilibrada e exercícios regulares podem ajudar.';
} else {
    classe   = 'Obesidade';
    cor      = '#E24B4A';
    descricao = 'Seu IMC indica obesidade. Recomendamos buscar orientação médica e nutricional.';
}

document.getElementById('saudacao').textContent      = 'Olá, ' + nome + '!';
document.getElementById('imc-valor').textContent     = imc.toFixed(1);
document.getElementById('imc-descricao').textContent = descricao;
document.getElementById('res-peso').textContent      = peso + ' kg';
document.getElementById('res-altura').textContent    = altura + ' cm';
document.getElementById('res-imc').textContent       = imc.toFixed(1);
document.getElementById('res-classe').textContent    = classe;

const badge = document.getElementById('imc-badge');
badge.textContent      = classe;
badge.style.background = cor + '22';
badge.style.color      = cor;

const pct = Math.min(Math.max(((imc - 15) / 25) * 100, 2), 98);
document.getElementById('imc-marcador').style.left = pct + '%';