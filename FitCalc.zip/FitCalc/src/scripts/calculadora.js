
function irParaResultado() {
    const nome   = document.getElementById('nome').value.trim();
    const peso   = parseFloat(document.getElementById('peso').value);
    const altura = parseFloat(document.getElementById('altura').value);

    if (!peso || !altura || peso <= 0 || altura <= 0) {
        alert('Por favor, preencha peso e altura corretamente.');
        return;
    }

    // Salva os dados e redireciona
    localStorage.setItem('fitcalc_nome',   nome || 'Você');
    localStorage.setItem('fitcalc_peso',   peso);
    localStorage.setItem('fitcalc_altura', altura);

    window.location.href = './resultado.html';
}