const treinos = {
    abaixo: [
        {tipo:"Peito", nome:"Supino reto", rep:"4x8", link:"https://www.hipertrofia.org/blog/supino-reto/"},
        {tipo:"Ombro", nome:"Desenvolvimento militar", rep:"4x8", link:"https://www.tuasaude.com/desenvolvimento-militar/"},
        {tipo:"Braço", nome:"Rosca direta", rep:"4x10", link:"https://www.hipertrofia.org/blog/rosca-direta/"},
        {tipo:"Perna", nome:"Agachamento livre", rep:"4x8", link:"https://www.tuasaude.com/agachamento/"},
        {tipo:"Abdômen", nome:"Crunch abdominal", rep:"3x20", link:"https://www.tuasaude.com/abdominal/"},
        {tipo:"Costas", nome:"Remada curvada", rep:"4x8", link:"https://www.hipertrofia.org/blog/remada-curvada/"}
    ],

    normal: [
        {tipo:"Peito", nome:"Supino inclinado", rep:"4x12", link:"https://www.hipertrofia.org/blog/supino-inclinado/"},
        {tipo:"Ombro", nome:"Elevação lateral", rep:"4x15", link:"https://www.tuasaude.com/elevacao-lateral/"},
        {tipo:"Braço", nome:"Tríceps pulley", rep:"4x12", link:"https://www.hipertrofia.org/blog/triceps-pulley/"},
        {tipo:"Perna", nome:"Leg press", rep:"4x12", link:"https://www.tuasaude.com/leg-press/"},
        {tipo:"Abdômen", nome:"Prancha", rep:"3x45s", link:"https://www.tuasaude.com/prancha-abdominal/"},
        {tipo:"Costas", nome:"Puxada frontal", rep:"4x12", link:"https://www.hipertrofia.org/blog/puxada-frontal/"}
    ],

    sobrepeso: [
        {tipo:"Peito", nome:"Flexão inclinada", rep:"3x12", link:"https://www.tuasaude.com/flexao-de-braco/"},
        {tipo:"Ombro", nome:"Elevação frontal", rep:"3x15", link:"https://www.hipertrofia.org/blog/elevacao-frontal/"},
        {tipo:"Braço", nome:"Rosca alternada", rep:"3x12", link:"https://www.tuasaude.com/rosca-alternada/"},
        {tipo:"Perna", nome:"Agachamento com apoio", rep:"3x15", link:"https://www.tuasaude.com/agachamento/"},
        {tipo:"Abdômen", nome:"Abdominal sentado", rep:"3x20", link:"https://www.tuasaude.com/abdominal/"},
        {tipo:"Costas", nome:"Remada baixa", rep:"3x12", link:"https://www.hipertrofia.org/blog/remada-baixa/"}
    ],

    obesidade: [
        {tipo:"Peito", nome:"Flexão na parede", rep:"3x10", link:"https://www.tuasaude.com/flexao-de-braco/"},
        {tipo:"Ombro", nome:"Rotação de ombros", rep:"3x20", link:"https://www.tuasaude.com/exercicios-para-ombro/"},
        {tipo:"Braço", nome:"Rosca com elástico", rep:"3x12", link:"https://www.hipertrofia.org/blog/"},
        {tipo:"Perna", nome:"Agachamento parcial", rep:"3x10", link:"https://www.tuasaude.com/agachamento/"},
        {tipo:"Abdômen", nome:"Contração abdominal", rep:"3x15", link:"https://www.tuasaude.com/abdominal/"},
        {tipo:"Costas", nome:"Alongamento dorsal", rep:"3x20s", link:"https://www.tuasaude.com/alongamento/"}
    ]
};

function gerarTreinos() {
    const categoria = document.getElementById("categoria").value;
    const resultado = document.getElementById("resultado");

    resultado.innerHTML = "";

    if (!categoria) {
        resultado.innerHTML = "<p>Selecione uma categoria.</p>";
        return;
    }

    treinos[categoria].forEach(treino => {
        resultado.innerHTML += `
            <div class="card">
                <h3>Treino de ${treino.tipo}</h3>
                <p><strong>Exercício:</strong> ${treino.nome}</p>
                <p><strong>Repetições:</strong> ${treino.rep}</p>
                <a href="${treino.link}" target="_blank">Como fazer</a>
            </div>
        `;
    });
}